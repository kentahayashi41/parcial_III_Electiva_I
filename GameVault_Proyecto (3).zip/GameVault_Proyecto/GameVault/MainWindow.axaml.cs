using System.Collections.ObjectModel;
using Avalonia.Controls;
using Avalonia.Interactivity;
using GameVault.Data;
using GameVault.Models;
using GameVault.Services;

namespace GameVault;

public partial class MainWindow : Window
{
    private readonly VideojuegoServicio _servicio;
    private readonly ObservableCollection<Videojuego> _videojuegos = new();
    private int _idSeleccionado;

    public MainWindow()
    {
        InitializeComponent();
        _servicio = new VideojuegoServicio(new VideojuegoDAO());
        ListaVideojuegos.ItemsSource = _videojuegos;
        CargarVideojuegos();
    }

    private void CargarVideojuegos()
    {
        _videojuegos.Clear();
        foreach (var juego in _servicio.Listar())
            _videojuegos.Add(juego);
    }

    private Videojuego ObtenerDatosFormulario()
    {
        if (!decimal.TryParse(TxtPrecio.Text, out decimal precio))
            throw new ArgumentException("Escribe un precio válido. Ejemplo: 80000.");

        string estado = (CmbEstado.SelectedItem as ComboBoxItem)?.Content?.ToString()
                        ?? "Pendiente";

        return new Videojuego(
            _idSeleccionado,
            TxtNombre.Text?.Trim() ?? "",
            TxtGenero.Text?.Trim() ?? "",
            TxtPlataforma.Text?.Trim() ?? "",
            precio,
            estado
        );
    }

    private void Registrar_Click(object? sender, RoutedEventArgs e)
    {
        try
        {
            var juego = ObtenerDatosFormulario();
            _servicio.Registrar(juego);
            CargarVideojuegos();
            LimpiarFormulario();
            MostrarMensaje("Videojuego registrado correctamente.");
        }
        catch (Exception ex)
        {
            MostrarMensaje(ex.Message);
        }
    }

    private void Actualizar_Click(object? sender, RoutedEventArgs e)
    {
        try
        {
            var juego = ObtenerDatosFormulario();
            _servicio.Actualizar(juego);
            CargarVideojuegos();
            LimpiarFormulario();
            MostrarMensaje("Videojuego actualizado correctamente.");
        }
        catch (Exception ex)
        {
            MostrarMensaje(ex.Message);
        }
    }

    private void Eliminar_Click(object? sender, RoutedEventArgs e)
    {
        try
        {
            _servicio.Eliminar(_idSeleccionado);
            CargarVideojuegos();
            LimpiarFormulario();
            MostrarMensaje("Videojuego eliminado correctamente.");
        }
        catch (Exception ex)
        {
            MostrarMensaje(ex.Message);
        }
    }

    private void ListaVideojuegos_SelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (ListaVideojuegos.SelectedItem is not Videojuego juego)
            return;

        _idSeleccionado = juego.Id;
        TxtNombre.Text = juego.Nombre;
        TxtGenero.Text = juego.Genero;
        TxtPlataforma.Text = juego.Plataforma;
        TxtPrecio.Text = juego.Precio.ToString();
        CmbEstado.SelectedIndex = juego.Estado switch
        {
            "Jugando" => 1,
            "Completado" => 2,
            _ => 0
        };
        MostrarMensaje($"Seleccionado: {juego.Nombre}");
    }

    private void Limpiar_Click(object? sender, RoutedEventArgs e) => LimpiarFormulario();

    private void LimpiarFormulario()
    {
        _idSeleccionado = 0;
        TxtNombre.Text = "";
        TxtGenero.Text = "";
        TxtPlataforma.Text = "";
        TxtPrecio.Text = "";
        CmbEstado.SelectedIndex = 0;
        ListaVideojuegos.SelectedItem = null;
    }

    private void MostrarMensaje(string mensaje) => TxtMensaje.Text = mensaje;
}
