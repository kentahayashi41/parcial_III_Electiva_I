using GameVault.Data;
using GameVault.Models;

namespace GameVault.Services;

public class VideojuegoServicio
{
    private readonly VideojuegoDAO _dao;

    public VideojuegoServicio(VideojuegoDAO dao)
    {
        _dao = dao;
    }

    public void Registrar(Videojuego juego)
    {
        Validar(juego);
        _dao.Registrar(juego);
    }

    public List<Videojuego> Listar() => _dao.Listar();

    public void Actualizar(Videojuego juego)
    {
        if (juego.Id <= 0)
            throw new ArgumentException("Selecciona un videojuego para modificar.");

        Validar(juego);
        _dao.Actualizar(juego);
    }

    public void Eliminar(int id)
    {
        if (id <= 0)
            throw new ArgumentException("Selecciona un videojuego para eliminar.");

        _dao.Eliminar(id);
    }

    private static void Validar(Videojuego juego)
    {
        if (string.IsNullOrWhiteSpace(juego.Nombre))
            throw new ArgumentException("Escribe el nombre del videojuego.");

        if (string.IsNullOrWhiteSpace(juego.Genero))
            throw new ArgumentException("Escribe el género del videojuego.");

        if (string.IsNullOrWhiteSpace(juego.Plataforma))
            throw new ArgumentException("Escribe la plataforma.");

        if (juego.Precio < 0)
            throw new ArgumentException("El precio no puede ser negativo.");

        if (string.IsNullOrWhiteSpace(juego.Estado))
            throw new ArgumentException("Escribe el estado del videojuego.");
    }
}
