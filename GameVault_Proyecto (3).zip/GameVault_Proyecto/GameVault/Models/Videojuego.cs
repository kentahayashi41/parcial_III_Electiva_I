namespace GameVault.Models;

public class Videojuego
{
    public int Id { get; set; }
    public string Nombre { get; set; }
    public string Genero { get; set; }
    public string Plataforma { get; set; }
    public decimal Precio { get; set; }
    public string Estado { get; set; }

    public Videojuego(int id, string nombre, string genero, string plataforma,
                      decimal precio, string estado)
    {
        Id = id;
        Nombre = nombre;
        Genero = genero;
        Plataforma = plataforma;
        Precio = precio;
        Estado = estado;
    }

    public override string ToString() =>
        $"{Nombre}  |  {Plataforma}  |  {Estado}  |  ${Precio:N0}";
}
