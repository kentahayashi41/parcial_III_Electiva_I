using GameVault.Models;
using Microsoft.Data.Sqlite;

namespace GameVault.Data;

public class VideojuegoDAO
{
    public VideojuegoDAO() => ConexionBD.Inicializar();

    public void Registrar(Videojuego juego)
    {
        using var conexion = ConexionBD.ObtenerConexion();
        conexion.Open();

        const string sql = @"INSERT INTO Videojuegos
            (Nombre, Genero, Plataforma, Precio, Estado)
            VALUES (@nombre, @genero, @plataforma, @precio, @estado);";

        using var comando = new SqliteCommand(sql, conexion);
        AgregarParametros(comando, juego);
        comando.ExecuteNonQuery();
    }

    public List<Videojuego> Listar()
    {
        var lista = new List<Videojuego>();

        using var conexion = ConexionBD.ObtenerConexion();
        conexion.Open();

        const string sql = "SELECT * FROM Videojuegos ORDER BY Nombre;";
        using var comando = new SqliteCommand(sql, conexion);
        using var lector = comando.ExecuteReader();

        while (lector.Read())
        {
            lista.Add(new Videojuego(
                lector.GetInt32(0),
                lector.GetString(1),
                lector.GetString(2),
                lector.GetString(3),
                Convert.ToDecimal(lector.GetDouble(4)),
                lector.GetString(5)
            ));
        }

        return lista;
    }

    public void Actualizar(Videojuego juego)
    {
        using var conexion = ConexionBD.ObtenerConexion();
        conexion.Open();

        const string sql = @"UPDATE Videojuegos SET
            Nombre=@nombre, Genero=@genero, Plataforma=@plataforma,
            Precio=@precio, Estado=@estado WHERE Id=@id;";

        using var comando = new SqliteCommand(sql, conexion);
        AgregarParametros(comando, juego);
        comando.Parameters.AddWithValue("@id", juego.Id);
        comando.ExecuteNonQuery();
    }

    public void Eliminar(int id)
    {
        using var conexion = ConexionBD.ObtenerConexion();
        conexion.Open();

        using var comando = new SqliteCommand(
            "DELETE FROM Videojuegos WHERE Id=@id;", conexion);
        comando.Parameters.AddWithValue("@id", id);
        comando.ExecuteNonQuery();
    }

    private static void AgregarParametros(SqliteCommand comando, Videojuego juego)
    {
        comando.Parameters.AddWithValue("@nombre", juego.Nombre);
        comando.Parameters.AddWithValue("@genero", juego.Genero);
        comando.Parameters.AddWithValue("@plataforma", juego.Plataforma);
        comando.Parameters.AddWithValue("@precio", juego.Precio);
        comando.Parameters.AddWithValue("@estado", juego.Estado);
    }
}
