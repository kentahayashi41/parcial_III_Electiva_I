using Microsoft.Data.Sqlite;

namespace GameVault.Data;

public static class ConexionBD
{
    private static readonly string Carpeta = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "GameVault");

    private static readonly string RutaBD = Path.Combine(Carpeta, "gamevault.db");

    public static SqliteConnection ObtenerConexion()
    {
        Directory.CreateDirectory(Carpeta);
        return new SqliteConnection($"Data Source={RutaBD}");
    }

    public static void Inicializar()
    {
        using var conexion = ObtenerConexion();
        conexion.Open();

        var sql = @"
            CREATE TABLE IF NOT EXISTS Videojuegos (
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Nombre TEXT NOT NULL,
                Genero TEXT NOT NULL,
                Plataforma TEXT NOT NULL,
                Precio REAL NOT NULL,
                Estado TEXT NOT NULL
            );";

        using var comando = new SqliteCommand(sql, conexion);
        comando.ExecuteNonQuery();
    }
}
